// ضع هنا إعدادات مشروع Firebase (تيجي من: Project settings > Your apps > Web app > firebaseConfig)
// لو سبتها فاضية التطبيق بيشتغل في «وضع تجريبي» ببيانات وهمية على الجهاز بس.
window.FIREBASE_CONFIG = null;
/* مثال:
window.FIREBASE_CONFIG = {
  apiKey: "...", authDomain: "...firebaseapp.com", projectId: "...",
  storageBucket: "...", messagingSenderId: "...", appId: "..."
};
*/

// رابط موقع التطبيق على الإنترنت (اختياري) لو عملت Firebase Hosting، مثال: "https://اسم-مشروعك.web.app/"
window.SHARE_BASE = "";
