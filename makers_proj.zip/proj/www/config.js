window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyAnAXTCaeTSOUfBpM8G-ZwNosHz3iHcvgI",
  authDomain: "arab-makers.firebaseapp.com",
  projectId: "arab-makers",
  storageBucket: "arab-makers.firebasestorage.app",
  messagingSenderId: "569614944909",
  appId: "1:569614944909:web:023bcce59558d0ff3f30c4"
};
window.SHARE_BASE = "";

// وسيلة التواصل للمساعدة (واتساب بالكود الدولي من غير + أو أصفار، وإيميل). اتركها فاضية لو لسه.
window.SUPPORT_WA = "";
window.SUPPORT_EMAIL = "eng.khaled.musician@gmail.com";

// إيميل الأدمن (صاحب لوحة المراجعة)
window.ADMIN_EMAIL = "eng_khaled_hussin@yahoo.com";

// ===== إعدادات الإطلاق =====
window.REQUIRE_LOGIN_TO_CONTACT = true;   // أزرار التواصل تحتاج تسجيل مشتري
window.RATE_PROMPT_ON = false;            // فعّلها true بعد نشر التطبيق على Google Play
window.PLAY_URL = "https://play.google.com/store/apps/details?id=com.almarefa.arabmakers";
