// طبقة الخلفية: Firebase الحقيقي، أو وضع تجريبي بالذاكرة لو مفيش إعدادات
const V = "10.12.2";
let impl;
if (window.FIREBASE_CONFIG) {
  const base = `https://www.gstatic.com/firebasejs/${V}/`;
  const [{ initializeApp }, A, S] = await Promise.all([
    import(base + "firebase-app.js"), import(base + "firebase-auth.js"), import(base + "firebase-firestore.js")
  ]);
  const app = initializeApp(window.FIREBASE_CONFIG);
  const auth = A.getAuth(app), db = S.getFirestore(app);
  const rows = snap => snap.docs.map(d => ({ id: d.id, ...d.data() }));
  const mdoc = uid => S.doc(db, "makers", uid);
  impl = {
    demo: false,
    onAuth: cb => A.onAuthStateChanged(auth, u => cb(u ? { uid: u.uid, email: u.email, name: u.displayName || "", anon: u.isAnonymous, verified: u.emailVerified } : null)),
    async signUp(e, p, name) { const c = await A.createUserWithEmailAndPassword(auth, e, p); if (name) { try { await A.updateProfile(c.user, { displayName: name }) } catch (x) {} } try { await A.sendEmailVerification(c.user) } catch (x) {} return c; },
    async sendVerify() { await A.sendEmailVerification(auth.currentUser); },
    async refreshUser() { await auth.currentUser.reload(); await auth.currentUser.getIdToken(true); const u = auth.currentUser; return { uid: u.uid, email: u.email, name: u.displayName || "", anon: false, verified: u.emailVerified }; },
    signIn: (e, p) => A.signInWithEmailAndPassword(auth, e, p),
    signOut: () => A.signOut(auth),
    async signAnon() { try { await A.signInAnonymously(auth) } catch (e) {} },
    // ---- المصنّعين ----
    async listMakers(country) { return rows(await S.getDocs(S.query(S.collection(db, "makers"), S.where("country", "==", country), S.limit(300)))); },
    async getMaker(id) { const d = await S.getDoc(mdoc(id)); return d.exists() ? { id, ...d.data() } : null; },
    async saveMaker(uid, data) { await S.setDoc(mdoc(uid), data, { merge: true }); },
    // ---- المنتجات ----
    async listProducts(id) { return rows(await S.getDocs(S.collection(db, "makers", id, "products"))); },
    async getProduct(uid, pid) { const d = await S.getDoc(S.doc(db, "makers", uid, "products", pid)); return d.exists() ? { id: pid, uid, ...d.data() } : null; },
    async feed() { return (await S.getDocs(S.query(S.collectionGroup(db, "products"), S.limit(400)))).docs.map(d => ({ id: d.id, uid: d.ref.parent.parent.id, ...d.data() })); },
    async deleteProduct(uid, pid) { await S.deleteDoc(S.doc(db, "makers", uid, "products", pid)); },
    // ---- العدّادات ----
    async bumpMaker(uid, field) { try { await S.updateDoc(mdoc(uid), { [field]: S.increment(1) }) } catch (e) {} },
    async bumpProduct(uid, pid) { try { await S.updateDoc(S.doc(db, "makers", uid, "products", pid), { views: S.increment(1) }) } catch (e) {} },
    // ---- المراجعة ----
    async addPending(uid, it) {
      await S.addDoc(S.collection(db, "makers", uid, "pending"), { ...it, ts: Date.now() });
      await S.setDoc(mdoc(uid), { hasPending: true }, { merge: true });
    },
    async listPending(uid) { return rows(await S.getDocs(S.collection(db, "makers", uid, "pending"))); },
    async delPending(uid, id) { await S.deleteDoc(S.doc(db, "makers", uid, "pending", id)); },
    async clearFlag(uid) { const l = await this.listPending(uid); if (!l.length) await S.setDoc(mdoc(uid), { hasPending: false }, { merge: true }); },
    async listPendingMakers() { return rows(await S.getDocs(S.query(S.collection(db, "makers"), S.where("hasPending", "==", true), S.limit(100)))); },
    async approve(uid, it) {
      if (it.kind === "photo") await S.updateDoc(mdoc(uid), { photos: S.arrayUnion(it.photo) });
      else await S.addDoc(S.collection(db, "makers", uid, "products"), { name: it.name || "", price: it.price || "", desc: it.desc || "", photo: it.photo || "", photos: it.photos || [], specs: it.specs || [], sizes: it.sizes || null, cat: it.cat || "", country: it.country || "", ts: Date.now(), views: 0 });
      await this.delPending(uid, it.id); await this.clearFlag(uid);
    },
    async reject(uid, it) { await this.delPending(uid, it.id); await this.clearFlag(uid); },
    // ---- البلاغات والتقييمات ----
    async addReport(r) { await S.addDoc(S.collection(db, "reports"), { ...r, ts: Date.now() }); },
    async listReports() { return rows(await S.getDocs(S.query(S.collection(db, "reports"), S.limit(100)))); },
    async delReport(id) { await S.deleteDoc(S.doc(db, "reports", id)); },
    async listReviews(maker) { return rows(await S.getDocs(S.query(S.collection(db, "reviews"), S.where("maker", "==", maker), S.limit(100)))).sort((a, b) => (b.ts || 0) - (a.ts || 0)); },
    async saveReview(r) { await S.setDoc(S.doc(db, "reviews", r.maker + "_" + r.uid), { ...r, ts: Date.now() }); },
    async delReview(id) { await S.deleteDoc(S.doc(db, "reviews", id)); },
    // ---- حذف الحساب ----
    async deleteAccount(uid) {
      for (const n of ["products", "pending"]) { const s = await S.getDocs(S.collection(db, "makers", uid, n)); for (const d of s.docs) await S.deleteDoc(d.ref); }
      const rv = await S.getDocs(S.query(S.collection(db, "reviews"), S.where("uid", "==", uid))); for (const d of rv.docs) await S.deleteDoc(d.ref);
      try { await S.deleteDoc(mdoc(uid)) } catch (e) {}
      await A.deleteUser(auth.currentUser);
    }
  };
} else {
  // ---- وضع تجريبي ----
  const ls = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d } catch (e) { return d } };
  const sv = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)) } catch (e) {} };
  let makers = ls("demo_makers", null);
  if (!makers) {
    makers = [
      { id: "d1", name: "مصنع النيل للملابس الجاهزة", country: "EG", city: "القاهرة - العبور", cats: ["clothes:women", "clothes:jeans"], desc: "ننتج ملابس حريمي وجينز بالجملة، أقل كمية 50 قطعة، خامات مصرية وتسليم خلال 10 أيام.", phone: "01000000001", wa: "201000000001", photos: [], verified: true, featured: true, created: 3, views: 40, waClicks: 6, plan: "pro" },
      { id: "d2", name: "ورشة الأمل لأثاث غرف النوم", country: "EG", city: "دمياط", cats: ["furniture:home", "furniture:wood"], desc: "غرف نوم وأطقم صالون بتصميمات حديثة، نصنع حسب الطلب.", phone: "01000000002", wa: "201000000002", photos: [], verified: false, featured: false, created: 2, views: 12 },
      { id: "d3", name: "الحرفة للبلاستيك المنزلي", country: "EG", city: "6 أكتوبر", cats: ["plastic:houseware"], desc: "أدوات منزلية بلاستيك: سلال، أحواض، علب تخزين.", phone: "01000000003", wa: "201000000003", photos: [], verified: false, featured: false, created: 1, views: 3 },
      { id: "d4", name: "نجوم الخليج للتغليف", country: "AE", city: "الشارقة", cats: ["pack:cartons"], desc: "كراتين تغليف وطباعة بالجملة.", phone: "0500000004", wa: "9710500000004", photos: [], verified: true, featured: false, created: 1 }
    ];
    sv("demo_makers", makers);
  }
  let products = ls("demo_products", {
    d1: [{ id: "p1", name: "فستان سواريه", price: "350 جنيه للقطعة", desc: "مقاسات 36 إلى 50", photo: "", photos: [], cat: "clothes:women", country: "EG", views: 9, specs: [{ k: "الخامة", v: "ساتان" }, { k: "اللون", v: "أسود / أحمر" }], sizes: { cols: ["المقاس", "الصدر", "الطول"], rows: [["36", "88", "120"], ["38", "92", "122"]] } }],
    d2: [{ id: "p2", name: "غرفة نوم كاملة", price: "28,000 جنيه", desc: "خشب زان", photo: "", photos: [], cat: "furniture:home", country: "EG", views: 4 }],
    d3: [{ id: "p3", name: "سلة غسيل بلاستيك", price: "45 جنيه", desc: "سعة 40 لتر", photo: "", photos: [], cat: "plastic:houseware", country: "EG", views: 1 }]
  });
  let pend = ls("demo_pending", {}), reports = ls("demo_reports", []), reviews = ls("demo_reviews", []);
  let user = ls("demo_user", null); const subs = [];
  const emit = () => subs.forEach(f => f(user));
  const pub = u => u && { uid: u.uid, email: u.email, name: u.name || "", anon: false, verified: true };
  impl = {
    demo: true,
    onAuth: cb => { subs.push(cb); setTimeout(() => cb(pub(user)), 0); },
    async signUp(e, p, name) { user = { uid: "u_" + e.replace(/\W/g, ""), email: e, name }; sv("demo_user", user); emit(); },
    async signIn(e, p) { user = { uid: "u_" + e.replace(/\W/g, ""), email: e, name: (user && user.name) || e.split("@")[0] }; sv("demo_user", user); emit(); },
    async signOut() { user = null; sv("demo_user", null); emit(); },
    async signAnon() {},
    async sendVerify() {},
    async refreshUser() { return pub(user) },
    async listMakers(c) { return makers.filter(m => m.country === c); },
    async getMaker(id) { return makers.find(m => m.id === id) || null; },
    async saveMaker(uid, d) { const i = makers.findIndex(m => m.id === uid); if (i < 0) makers.push({ id: uid, ...d }); else makers[i] = { ...makers[i], ...d }; sv("demo_makers", makers); },
    async listProducts(id) { return products[id] || []; },
    async getProduct(uid, pid) { const p = (products[uid] || []).find(x => x.id === pid); return p ? { ...p, uid } : null; },
    async feed() { return Object.entries(products).flatMap(([uid, l]) => l.map(p => ({ ...p, uid }))); },
    async deleteProduct(uid, pid) { products[uid] = (products[uid] || []).filter(x => x.id !== pid); sv("demo_products", products); },
    async bumpMaker(uid, f) { const m = makers.find(x => x.id === uid); if (m) { m[f] = (m[f] || 0) + 1; sv("demo_makers", makers); } },
    async bumpProduct(uid, pid) { const p = (products[uid] || []).find(x => x.id === pid); if (p) { p.views = (p.views || 0) + 1; sv("demo_products", products); } },
    async addPending(uid, it) { (pend[uid] = pend[uid] || []).push({ id: "q" + Date.now() + Math.random(), ...it }); sv("demo_pending", pend); },
    async listPending(uid) { return pend[uid] || []; },
    async delPending(uid, id) { pend[uid] = (pend[uid] || []).filter(x => x.id !== id); sv("demo_pending", pend); },
    async clearFlag() {},
    async listPendingMakers() { return makers.filter(m => (pend[m.id] || []).length); },
    async approve(uid, it) {
      if (it.kind === "photo") { const m = makers.find(x => x.id === uid); m.photos = [...(m.photos || []), it.photo]; sv("demo_makers", makers); }
      else { (products[uid] = products[uid] || []).push({ id: "p" + Date.now(), name: it.name, price: it.price, desc: it.desc, photo: it.photo, photos: it.photos || [], specs: it.specs || [], sizes: it.sizes || null, cat: it.cat || "", country: it.country || "", views: 0 }); sv("demo_products", products); }
      await this.delPending(uid, it.id);
    },
    async reject(uid, it) { await this.delPending(uid, it.id); },
    async addReport(r) { reports.push({ id: "r" + Date.now(), ...r, ts: Date.now() }); sv("demo_reports", reports); },
    async listReports() { return reports; },
    async delReport(id) { reports = reports.filter(r => r.id !== id); sv("demo_reports", reports); },
    async listReviews(maker) { return reviews.filter(r => r.maker === maker).sort((a, b) => (b.ts || 0) - (a.ts || 0)); },
    async saveReview(r) { reviews = reviews.filter(x => x.id !== r.maker + "_" + r.uid); reviews.push({ id: r.maker + "_" + r.uid, ...r, ts: Date.now() }); sv("demo_reviews", reviews); },
    async delReview(id) { reviews = reviews.filter(r => r.id !== id); sv("demo_reviews", reviews); },
    async deleteAccount(uid) { makers = makers.filter(m => m.id !== uid); delete products[uid]; delete pend[uid]; reviews = reviews.filter(r => r.uid !== uid); sv("demo_makers", makers); sv("demo_products", products); sv("demo_pending", pend); sv("demo_reviews", reviews); user = null; sv("demo_user", null); emit(); }
  };
}
export default impl;
