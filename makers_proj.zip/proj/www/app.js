import B from "./backend.js";
import { COUNTRIES, CATS, catName, countryName, CITIES, OTHER_CITY } from "./data.js";

const $ = s => document.querySelector(s);
const view = $("#view"), titleEl = $("#title");
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const store = { get(k) { try { return localStorage.getItem(k) } catch (e) { return null } }, set(k, v) { try { localStorage.setItem(k, v) } catch (e) {} } };
const seen = { has(k) { try { return !!sessionStorage.getItem(k) } catch (e) { return false } }, add(k) { try { sessionStorage.setItem(k, "1") } catch (e) {} } };
let user = null, cache = {}, feedCache = null, anonTried = false;

// ---- الباقات والحدود ----
const FREE = { photos: 3, products: 8, pphotos: 1 }, PRO = { photos: 6, products: 100, pphotos: 6 };
const TRIAL_DAYS = 90, DAY = 864e5;
const trialEnd = m => (m.created || 0) + TRIAL_DAYS * DAY;
const inTrial = m => !!m.created && Date.now() < trialEnd(m);
const hasPro = m => !!m && (m.plan === "pro" || inTrial(m));
const lim = m => hasPro(m) ? PRO : FREE;
const isAdmin = () => !!(user && user.verified !== false && window.ADMIN_EMAIL && String(user.email).toLowerCase() === String(window.ADMIN_EMAIL).toLowerCase());
const needLogin = () => window.REQUIRE_LOGIN_TO_CONTACT !== false && !user;

// ---- حماية المحتوى ----
const BAD = /(https?:\/\/|www\.|\b[a-z0-9-]+\.(com|net|org|info|me|io|xyz|ly|co)\b|t\.me|wa\.me|bit\.ly|@[a-z0-9_]{3,})/i;
const hasLink = (...a) => a.some(x => BAD.test(x || ""));
const LINK_MSG = "ممنوع وضع روابط أو حسابات تواصل في النصوص. استخدم خانة الهاتف والواتساب.";

// ---- ترتيب حسب الإقبال ----
const score = m => (m.views | 0) + 5 * (m.waClicks | 0) + 5 * (m.callClicks | 0) + 2 * (m.shares | 0);
const rank = (a, b) => (b.featured | 0) - (a.featured | 0) || ((b.plan === "pro") | 0) - ((a.plan === "pro") | 0) || (b.verified | 0) - (a.verified | 0) || score(b) - score(a) || (b.created || 0) - (a.created || 0);

if (B.demo) $("#demo").hidden = false;
function toast(t) { const e = $("#toast"); e.textContent = t; e.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => e.hidden = true, 2800) }
function setTitle(t) { titleEl.textContent = t }
const go = h => { location.hash = h };
$("#back").onclick = () => { if (history.length > 1 && location.hash && location.hash !== "#/") history.back(); else go("#/") };
$("#acct").onclick = () => go(user ? "#/me" : "#/login");
titleEl.onclick = () => go("#/");

B.onAuth(u => {
  user = u && !u.anon ? u : null;
  if (!u && !anonTried) { anonTried = true; B.signAnon && B.signAnon(); }
  route();
});
window.addEventListener("hashchange", route);

async function makers(c, force) { if (force || !cache[c]) cache[c] = (await B.listMakers(c)).filter(m => !m.hidden); return cache[c] }
async function getFeed(force) {
  if (force || !feedCache) {
    const [all] = await Promise.all([B.feed()]);
    feedCache = all;
  }
  return feedCache;
}
const catMain = id => String(id || "").split(":")[0];

async function route() {
  const p = (location.hash || "#/").slice(2).split("/").map(decodeURIComponent);
  window.scrollTo(0, 0);
  $("#back").style.visibility = p[0] ? "visible" : "hidden";
  try {
    if (!p[0]) return home();
    if (p[0] === "countries") return countries();
    if (p[0] === "c") return p[2] === "cat" ? list(p[1], p[3]) : country(p[1]);
    if (p[0] === "m") return maker(p[1]);
    if (p[0] === "p") return product(p[1], p[2]);
    if (p[0] === "login") return login(p[1]);
    if (p[0] === "help") return help();
    if (p[0] === "me") return me();
    if (p[0] === "admin") return admin();
    if (p[0] === "privacy") return legal("privacy");
    if (p[0] === "terms") return legal("terms");
    home();
  } catch (e) { view.innerHTML = `<div class="empty">حصلت مشكلة في التحميل. تأكد من الإنترنت وجرّب تاني.<br><small>${esc(e.message)}</small></div>` }
}

// ================= الرئيسية: منتجات =================
function countries() {
  setTitle("اختر دولتك");
  view.innerHTML = `<h2>اختر دولتك</h2><div class="grid">${COUNTRIES.map(c => `<div class="tile" data-c="${c[0]}"><span>${c[2]}</span>${c[1]}</div>`).join("")}</div>`;
  view.querySelectorAll(".tile").forEach(t => t.onclick = () => { store.set("country", t.dataset.c); feedCache = null; go("#/") });
}

// ===== بحث ذكي (تطبيع عربي + مرادفات) =====
const SYN = [["شنطه","شنط","شنت","حقيبه","حقائب","حقايب","bag","bags","handbag"],["كرسي","كراسي","مقعد","مقاعد"],["طاوله","طاولات","ترابيزه","ترابيزات","منضده"],["حذاء","احذيه","جزمه","جزم","صندل","shoes","shoe"],["قماش","اقمشه","قمش","نسيج","اقمشة"],["ملابس","هدوم","لبس","ازياء","فساتين","تيشيرت"],["كرتون","كراتين","علب","علبه","تغليف"],["دهان","دهانات","طلاء","بويه"],["رخام","جرانيت"],["اثاث","موبيليا","مفروشات"],["شبابيك","نوافذ","شباك"],["حديد","صلب","ستيل"],["العاب","لعبه","لعب"],["عطر","عطور","برفان"],["صابون","منظفات","منظف"],["كابلات","كابل","اسلاك","سلك"],["اضاءه","اضاءة","لمبات","لمبه","انارة","نجف"],["مطبخ","مطابخ","ادوات منزليه"],["سيراميك","بلاط","بورسلين"],["ابواب","باب"]];
const norm = s => String(s || "").toLowerCase().replace(/[\u064B-\u0652\u0640]/g, "").replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/ؤ/g, "و").replace(/ئ/g, "ي");
const stem = w => w.replace(/^(وال|بال|كال|فال|لل|ال)/, "");
function variants(tok) {
  const t = stem(tok), out = new Set([t]);
  for (const g of SYN) if (g.some(x => x === t || (t.length >= 3 && x.includes(t)))) g.forEach(x => out.add(x));
  return [...out];
}
function matcher(q) {
  const toks = norm(q).split(/\s+/).filter(Boolean);
  if (!toks.length) return null;
  const vs = toks.map(variants);
  return hay => { const h = norm(hay); return vs.every(v => v.some(x => h.includes(x))) };
}
const makerHay = (m, prods) => [m.name, m.desc, m.city, (m.cats || []).map(catName).join(" "), (prods || []).map(p => p.name + " " + (p.desc || "")).join(" ")].join(" ");
const prodHay = (p, m) => [p.name, p.desc, catName(p.cat || ""), (p.specs || []).map(x => x.k + " " + x.v).join(" "), m ? m.name + " " + (m.city || "") : ""].join(" ");

function pcard(p, mk) {
  const im = (p.photos && p.photos[0]) || p.photo;
  return `<div class="pc" data-u="${esc(p.uid)}" data-p="${esc(p.id)}">${im ? `<img src="${im}" alt="">` : `<div class="ph">📦</div>`}
  <div class="pi"><div class="nm">${esc(p.name)}</div><div class="pr2">${esc(p.price || "")}</div>
  <div class="sm">${esc(mk ? mk.name : "")}${mk && mk.verified ? ' <span class="badge">موثّق</span>' : ""}${mk && mk.featured ? ' <span class="badge f">مميّز</span>' : ""}</div></div></div>`;
}
const bindP = root => root.querySelectorAll(".pc").forEach(c => c.onclick = () => go(`#/p/${encodeURIComponent(c.dataset.u)}/${encodeURIComponent(c.dataset.p)}`));

async function home() {
  setTitle("مصنّعي الوطن العربي");
  const c = store.get("country");
  if (!c) return countries();
  view.innerHTML = `<div class="top2"><button class="chip" id="chg">${esc(COUNTRIES.find(x => x[0] === c)?.[2] || "")} ${esc(countryName(c))} ▾</button><a class="chip" href="#/c/${c}">🏭 تصفح المصنّعين والأقسام</a></div>
  <input id="q" type="search" placeholder="ابحث عن منتج أو مصنع...">
  <select id="cityf"></select>
  <div class="hs" id="cf"><span class="chip on" data-k="">الكل</span>${CATS.map(k => `<span class="chip" data-k="${k.id}">${k.icon} ${k.name}</span>`).join("")}</div>
  <div id="feed" class="empty">جاري التحميل…</div>
  <div class="note">منصّة تعارف بين المصنّعين والورش والتجّار في الوطن العربي. التسجيل مجاني.</div>
  ${user ? "" : `<a class="btn" href="#/login/buyer">🛒 سجّل كمشتري (مجاني)</a><a class="btn o" href="#/login/seller">🏭 سجّل مصنعك أو ورشتك</a>`}
  <div class="foot"><a href="#/help">الدعم</a> · <a href="#/privacy">الخصوصية</a> · <a href="#/terms">الشروط</a></div>`;
  $("#chg").onclick = () => go("#/countries");
  const [ms, all] = await Promise.all([makers(c), getFeed()]);
  const mk = Object.fromEntries(ms.map(m => [m.id, m]));
  let items = all.filter(p => mk[p.uid]);
  const pscore = p => (p.views | 0) * 2 + score(mk[p.uid]) * 0.3;
  items.sort((a, b) => rank(mk[a.uid], mk[b.uid]) || pscore(b) - pscore(a));
  let cat = "", cityV = "";
  const cl = [...new Set([...(CITIES[c] || []), ...ms.map(m => m.city).filter(Boolean)])];
  $("#cityf").innerHTML = `<option value="">📍 كل المدن</option>` + cl.map(x => `<option>${esc(x)}</option>`).join("");
  $("#cityf").onchange = () => { cityV = $("#cityf").value; draw() };
  const byMaker = {};
  items.forEach(p => (byMaker[p.uid] = byMaker[p.uid] || []).push(p));
  const draw = () => {
    const q = $("#q").value.trim(), mt = matcher(q);
    const catOk = ck => !cat || ck === cat;
    const ph = items.filter(p => (!cityV || (mk[p.uid].city || "") === cityV) && catOk(catMain(p.cat || (mk[p.uid].cats || [])[0])) && (!mt || mt(prodHay(p, mk[p.uid]))));
    let html = "";
    if (mt) {
      const mh = ms.filter(m => (!cityV || (m.city || "") === cityV) && (!cat || (m.cats || []).some(x => catMain(x) === cat)) && mt(makerHay(m, byMaker[m.id]))).sort(rank);
      if (mh.length) html += `<h2>🏭 المصنّعون (${mh.length})</h2>` + mh.map(card).join("");
      if (ph.length) html += `<h2>🛍 المنتجات (${ph.length})</h2><div class="pgrid">${ph.map(p => pcard(p, mk[p.uid])).join("")}</div>`;
      if (!html) html = `<div class="empty">مفيش نتائج لـ «${esc(q)}»<br><span class="sm">جرّب كلمة تانية أو اختار «كل المدن»</span></div>`;
    } else {
      html = ph.length ? `<div class="pgrid">${ph.map(p => pcard(p, mk[p.uid])).join("")}</div>` : `<div class="empty">لسه مفيش منتجات هنا. كن أول من يضيف منتجاته! 🏭</div>`;
    }
    $("#feed").className = "";
    $("#feed").innerHTML = html;
    bindP($("#feed")); bindCards($("#feed"));
  };
  draw();
  $("#q").oninput = draw;
  view.querySelectorAll("#cf .chip").forEach(ch => ch.onclick = () => { cat = ch.dataset.k; view.querySelectorAll("#cf .chip").forEach(x => x.classList.toggle("on", x === ch)); draw() });
}

// ================= الأقسام والمصنّعين =================
async function country(c) {
  setTitle(countryName(c));
  view.innerHTML = `<input id="q" type="search" placeholder="ابحث عن مصنع...">
  <div id="res"></div><div id="cats"><h2>الأقسام</h2>${CATS.map(k => `<div class="cat" data-k="${k.id}"><div class="h"><span>${k.icon}</span><span>${k.name}</span><span class="ar">›</span></div><div class="subs">
  <div data-cat="${k.id}"><b>كل ${k.name}</b></div>${k.sub.map(s => `<div data-cat="${k.id}:${s[0]}">${s[1]}</div>`).join("")}</div></div>`).join("")}</div>
  <a class="btn l" href="#/c/${c}/cat/all">عرض كل المصنّعين في ${esc(countryName(c))}</a>`;
  view.querySelectorAll(".cat>.h").forEach(h => h.onclick = () => h.parentElement.classList.toggle("open"));
  view.querySelectorAll(".subs div").forEach(d => d.onclick = () => go(`#/c/${c}/cat/${encodeURIComponent(d.dataset.cat)}`));
  const q = $("#q"), res = $("#res");
  q.oninput = async () => {
    const t = q.value.trim(), mt = matcher(t);
    $("#cats").style.display = t ? "none" : "";
    if (!mt) { res.innerHTML = ""; return }
    const [all, feedAll] = await Promise.all([makers(c), getFeed()]);
    const pm = {}; feedAll.forEach(p => (pm[p.uid] = pm[p.uid] || []).push(p));
    const hit = all.filter(m => mt(makerHay(m, pm[m.id]))).sort(rank);
    res.innerHTML = hit.length ? hit.map(card).join("") : `<div class="empty">مفيش نتائج لـ «${esc(t)}»</div>`;
    bindCards(res);
  };
}

function card(m) {
  const im = m.photos && m.photos[0] ? `<img class="thumb" src="${m.photos[0]}" alt="">` : `<div class="thumb">🏭</div>`;
  return `<div class="card ${m.featured ? "feat" : ""}"><div class="row" data-id="${esc(m.id)}">${im}<div><div class="nm">${esc(m.name)}${m.verified ? '<span class="badge">موثّق</span>' : ""}${m.featured ? '<span class="badge f">مميّز</span>' : ""}</div>
  <div class="sm">📍 ${esc(m.city || "")}</div><div class="sm">${esc((m.desc || "").slice(0, 70))}${(m.desc || "").length > 70 ? "…" : ""}</div></div></div></div>`;
}
const bindCards = root => root.querySelectorAll(".row[data-id]").forEach(r => r.onclick = () => go("#/m/" + encodeURIComponent(r.dataset.id)));

async function list(c, cat) {
  const all = await makers(c);
  const name = cat === "all" ? "كل المصنّعين" : (CATS.find(k => k.id === cat)?.name || catName(cat));
  setTitle(name);
  const hit = all.filter(m => cat === "all" || (m.cats || []).some(x => x === cat || x.startsWith(cat + ":"))).sort(rank);
  view.innerHTML = `<div class="sm" style="color:var(--m);margin-bottom:10px">${esc(countryName(c))} — ${hit.length} نتيجة</div>` +
    (hit.length ? hit.map(card).join("") : `<div class="empty">لسه مفيش مصنّعين في القسم ده.<br>كن أول من يسجّل!</div><a class="btn o" href="#/login/seller">سجّل مصنعك مجانًا</a>`);
  bindCards(view);
}

// ================= أدوات مشتركة للتواصل والإبلاغ =================
function contactButtons(m, text, extra = "") {
  const wa = String(m.wa || m.phone || "").replace(/\D/g, "");
  if (needLogin()) return `<div class="note">🔒 سجّل دخول كمشتري (مجاناً) عشان تشوف أرقام التواصل وتكلّم المصنع.</div><a class="btn w" href="#/login/buyer" id="needlogin">سجّل أو ادخل للتواصل</a>`;
  const w = wa ? `https://wa.me/${wa}?text=${encodeURIComponent(text)}` : "";
  return `${w ? `<a class="btn w" data-bump="waClicks" href="${w}" target="_blank" rel="noopener">💬 ابدأ المحادثة</a>` : ""}${extra}
  ${m.phone ? `<a class="btn l" data-bump="callClicks" href="tel:${esc(m.phone)}">📞 اتصال ${esc(m.phone)}</a>` : ""}`;
}
function bindBump(root, uid) { root.querySelectorAll("[data-bump]").forEach(a => a.addEventListener("click", () => B.bumpMaker(uid, a.dataset.bump))) }
function reportBox(box, data) {
  box.innerHTML = `<div class="card" style="padding:12px"><label>سبب البلاغ</label><select id="r_why"><option>صور أو محتوى غير لائق</option><option>روابط أو إعلانات</option><option>نصب أو احتيال</option><option>معلومات غلط</option><option>سبب آخر</option></select><textarea id="r_txt" placeholder="تفاصيل (اختياري)" style="min-height:60px"></textarea><button class="btn o" id="r_send">إرسال البلاغ</button></div>`;
  $("#r_send").onclick = async () => {
    try { await B.addReport({ ...data, reason: $("#r_why").value, text: $("#r_txt").value.trim().slice(0, 500), by: user ? user.email : "" }); box.innerHTML = `<div class="note">شكراً، وصل البلاغ وهنراجعه.</div>` } catch (x) { toast("تعذّر إرسال البلاغ") }
  };
}
const stars = n => "★".repeat(n) + "☆".repeat(5 - n);

// ================= صفحة المصنع =================
async function maker(id) {
  const m = await B.getMaker(id);
  if (!m || (m.hidden && !isAdmin() && !(user && user.uid === id))) { view.innerHTML = `<div class="empty">الصفحة دي مش موجودة أو غير متاحة.</div>`; return }
  setTitle(m.name);
  if (!seen.has("mv" + id)) { seen.add("mv" + id); B.bumpMaker(id, "views") }
  const [prods, revs] = await Promise.all([B.listProducts(id), B.listReviews(id)]);
  const avg = revs.length ? revs.reduce((a, r) => a + r.stars, 0) / revs.length : 0;
  const base = window.SHARE_BASE || "";
  const link = base ? base + "#/m/" + encodeURIComponent(id) : "";
  const mine = user && user.uid === id;
  const myRev = user ? revs.find(r => r.uid === user.uid) : null;
  view.innerHTML = `${m.photos?.length ? `<div class="gal">${m.photos.map(p => `<img src="${p}" alt="">`).join("")}</div>` : ""}
  <h2 style="margin-top:12px">${esc(m.name)}${m.verified ? '<span class="badge">موثّق</span>' : ""}</h2>
  <div class="sm" style="color:var(--m)">📍 ${esc(m.city || "")} — ${esc(countryName(m.country))}${revs.length ? ` · <span class="stars">${stars(Math.round(avg))}</span> ${avg.toFixed(1)} (${revs.length})` : ""}</div>
  <div class="chips">${(m.cats || []).map(x => `<span class="chip">${esc(catName(x))}</span>`).join("")}</div>
  <p style="line-height:1.8;white-space:pre-wrap">${esc(m.desc || "")}</p>
  ${contactButtons(m, "السلام عليكم، شفت صفحتك على تطبيق مصنّعي الوطن العربي وعايز أستفسر.")}
  <button class="btn l" id="share">🔗 مشاركة الصفحة</button>
  ${prods.length ? `<h2>المنتجات</h2><div class="pgrid" id="mp">${prods.map(p => pcard({ ...p, uid: id }, null)).join("")}</div>` : ""}
  <h2>التقييمات${revs.length ? ` (${revs.length})` : ""}</h2>
  <div id="revs">${revs.length ? revs.map(r => `<div class="card" style="padding:10px"><div class="sm"><b>${esc(r.name || "مشتري")}</b> <span class="stars">${stars(r.stars)}</span></div><div style="line-height:1.7;white-space:pre-wrap">${esc(r.text || "")}</div>
    <div style="display:flex;gap:6px;margin-top:6px"><button class="chip" data-rr="${esc(r.id)}">🚩 إبلاغ</button>${user && r.uid === user.uid ? `<button class="chip" data-rd="${esc(r.id)}">حذف تقييمي</button>` : ""}</div></div>`).join("") : `<div class="empty">لسه مفيش تقييمات.</div>`}</div>
  <div id="rbox"></div>
  <div class="note">التطبيق وسيط تعارف فقط، وغير مسؤول عن أي اتفاق أو صفقة. ننصح بزيارة المصنع ومعاينة الشغل بنفسك قبل الاتفاق.</div>
  <button class="btn r" id="rep">🚩 إبلاغ عن هذه الصفحة</button><div id="repbox"></div>`;
  bindBump(view, id); bindP(view);
  const nl = $("#needlogin"); if (nl) nl.onclick = () => store.set("after", location.hash);
  $("#share").onclick = async () => {
    B.bumpMaker(id, "shares");
    const text = m.name + " — " + (m.city || "") + (link ? "\n" + link : "");
    try { if (navigator.share) await navigator.share({ title: m.name, text }); else { await navigator.clipboard.writeText(text); toast("تم نسخ البيانات") } } catch (e) { toast("تعذّرت المشاركة") }
  };
  $("#rep").onclick = () => reportBox($("#repbox"), { maker: id, name: m.name });
  view.querySelectorAll("[data-rr]").forEach(b => b.onclick = () => { const r = revs.find(x => x.id === b.dataset.rr); reportBox($("#rbox"), { maker: id, name: m.name, review: r.id, text0: (r.text || "").slice(0, 150) }) });
  view.querySelectorAll("[data-rd]").forEach(b => b.onclick = async () => { await B.delReview(b.dataset.rd); maker(id) });
  // نموذج التقييم
  if (mine) return;
  if (!user) { $("#rbox").innerHTML = `<a class="btn l" href="#/login/buyer" id="rlogin">سجّل دخول عشان تقيّم</a>`; $("#rlogin").onclick = () => store.set("after", location.hash); return }
  let st = myRev ? myRev.stars : 5;
  $("#rbox").innerHTML = `<div class="card" style="padding:12px"><b>${myRev ? "عدّل تقييمك" : "قيّم المصنع"}</b><div class="stp" id="stp">${[1, 2, 3, 4, 5].map(i => `<span data-s="${i}">${i <= st ? "★" : "☆"}</span>`).join("")}</div>
    <textarea id="rv_t" placeholder="اكتب رأيك في التعامل (من غير روابط)" style="min-height:70px">${esc(myRev ? myRev.text : "")}</textarea><button class="btn o" id="rv_s">${myRev ? "حفظ التعديل" : "إرسال التقييم"}</button></div>`;
  $("#stp").querySelectorAll("span").forEach(s => s.onclick = () => { st = +s.dataset.s; $("#stp").querySelectorAll("span").forEach(x => x.textContent = +x.dataset.s <= st ? "★" : "☆") });
  $("#rv_s").onclick = async () => {
    const text = $("#rv_t").value.trim();
    if (hasLink(text)) return toast(LINK_MSG);
    try { await B.saveReview({ maker: id, uid: user.uid, name: user.name || user.email.split("@")[0], stars: st, text: text.slice(0, 450) }); toast("شكراً على تقييمك ✔"); maybeRate(); maker(id) } catch (e) { toast("تعذّر إرسال التقييم: " + (e.code || e.message)) }
  };
}

// ================= صفحة المنتج =================
async function product(uid, pid) {
  const [p, m] = await Promise.all([B.getProduct(uid, pid), B.getMaker(uid)]);
  if (!p || !m || (m.hidden && !isAdmin())) { view.innerHTML = `<div class="empty">المنتج ده مش موجود أو غير متاح.</div>`; return }
  setTitle(p.name);
  if (!seen.has("pv" + pid)) { seen.add("pv" + pid); B.bumpProduct(uid, pid) }
  const ph = (p.photos && p.photos.length ? p.photos : (p.photo ? [p.photo] : []));
  const pro = hasPro(m);
  const msg = "السلام عليكم، استفسار عن المنتج: " + p.name + " (من تطبيق مصنّعي الوطن العربي)";
  const inq = pro ? `<a class="btn o" data-bump="waClicks" href="https://wa.me/${String(m.wa || m.phone || "").replace(/\D/g, "")}?text=${encodeURIComponent(msg + "\nأرجو إرسال السعر وأقل كمية والمواصفات.")}" target="_blank" rel="noopener">📩 أرسل استفسار</a>` : "";
  view.innerHTML = `${ph.length ? `<div class="gal">${ph.map(x => `<img src="${x}" alt="">`).join("")}</div>` : `<div class="ph big">📦</div>`}
  <h2 style="margin-top:12px">${esc(p.name)}</h2>
  ${p.price ? `<div class="pr2" style="font-size:18px">${esc(p.price)}</div>` : ""}
  <a class="card mk" href="#/m/${encodeURIComponent(uid)}" style="display:block;padding:10px;margin:10px 0;text-decoration:none;color:inherit"><b>${esc(m.name)}</b>${m.verified ? '<span class="badge">موثّق</span>' : ""}<div class="sm" style="color:var(--m)">📍 ${esc(m.city || "")} — ${esc(countryName(m.country))} ›</div></a>
  ${p.desc ? `<p style="line-height:1.8;white-space:pre-wrap">${esc(p.desc)}</p>` : ""}
  ${p.specs && p.specs.length ? `<h2>وصف المنتج</h2><table class="spec">${p.specs.map(s => `<tr><td>${esc(s.k)}</td><td>${esc(s.v)}</td></tr>`).join("")}</table>` : ""}
  ${p.sizes && p.sizes.cols && p.sizes.cols.length ? `<h2>جدول المقاسات</h2><div class="tw"><table class="sz"><tr>${p.sizes.cols.map(c => `<th>${esc(c)}</th>`).join("")}</tr>${p.sizes.rows.map(r => `<tr>${r.map(c => `<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</table></div>` : ""}
  ${contactButtons(m, msg, inq)}
  <button class="btn l" id="share">🔗 مشاركة المنتج</button>
  <div id="sim"></div>
  <button class="btn r" id="rep">🚩 إبلاغ عن المنتج</button><div id="repbox"></div>`;
  bindBump(view, uid);
  const nl = $("#needlogin"); if (nl) nl.onclick = () => store.set("after", location.hash);
  $("#share").onclick = async () => { B.bumpMaker(uid, "shares"); const text = p.name + " — " + m.name; try { if (navigator.share) await navigator.share({ title: p.name, text }); else { await navigator.clipboard.writeText(text); toast("تم النسخ") } } catch (e) { toast("تعذّرت المشاركة") } };
  $("#rep").onclick = () => reportBox($("#repbox"), { maker: uid, name: m.name, product: pid, text0: p.name });
  maybeRate();
  // منتجات مشابهة
  const [ms, all] = await Promise.all([makers(m.country), getFeed()]);
  const mk = Object.fromEntries(ms.map(x => [x.id, x]));
  const key = catMain(p.cat || (m.cats || [])[0]);
  const sim = all.filter(x => x.id !== pid && mk[x.uid] && catMain(x.cat || (mk[x.uid].cats || [])[0]) === key).sort((a, b) => (b.views | 0) - (a.views | 0)).slice(0, 8);
  if (sim.length) { $("#sim").innerHTML = `<h2>منتجات مشابهة</h2><div class="hs">${sim.map(x => pcard(x, mk[x.uid])).join("")}</div>`; bindP($("#sim")) }
}

// ================= رسالة التقييم على بلاي =================
function maybeRate() {
  if (!window.RATE_PROMPT_ON || store.get("rated")) return;
  const n = (+store.get("rate_n") || 0) + 1; store.set("rate_n", n);
  if (n < 4) return;
  store.set("rated", "1");
  const d = document.createElement("div"); d.className = "ratebox";
  d.innerHTML = `<b>عجبك التطبيق؟ 🌟</b><div class="sm">تقييمك على جوجل بلاي بيساعدنا نكبر.</div><div style="display:flex;gap:8px;margin-top:8px"><a class="btn o" style="margin:0" href="${esc(window.PLAY_URL || "")}" target="_blank" rel="noopener">قيّمنا ⭐</a><button class="btn l" style="margin:0" id="rx">لاحقاً</button></div>`;
  document.body.appendChild(d); d.querySelector("#rx").onclick = () => d.remove();
}

// ================= الدخول والتسجيل =================
function login(role) {
  setTitle("حسابي");
  let mode = "up", r = role === "seller" ? "seller" : "buyer";
  const draw = () => {
    view.innerHTML = `<h2>${mode === "up" ? "إنشاء حساب جديد" : "تسجيل الدخول"}</h2>
    <div class="note" style="background:#e8f5e9;border-color:#a5d6a7;color:#1b5e20">🎁 الاشتراك مجاني لأول 3 شهور تبدأ من تاريخ التسجيل.</div>
    ${mode === "up" ? `<div class="seg"><button class="${r === "buyer" ? "on" : ""}" data-r="buyer">🛒 مشتري</button><button class="${r === "seller" ? "on" : ""}" data-r="seller">🏭 بائع / مصنع</button></div>
    <label>الاسم</label><input id="nm" autocomplete="name">` : ""}
    <label>البريد الإلكتروني</label><input id="em" type="email" autocomplete="email" dir="ltr">
    <label>كلمة السر (6 حروف على الأقل)</label><input id="pw" type="password" autocomplete="current-password" dir="ltr">
    <button class="btn" id="go1">${mode === "up" ? "إنشاء الحساب" : "دخول"}</button>
    <button class="btn l" id="sw">${mode === "up" ? "عندي حساب — دخول" : "مفيش عندي حساب — إنشاء حساب"}</button>
    <div class="sm" style="color:var(--m);text-align:center">بالتسجيل أنت توافق على <a href="#/terms">الشروط</a> و<a href="#/privacy">سياسة الخصوصية</a></div>${helpBtn()}`;
    view.querySelectorAll(".seg button").forEach(b => b.onclick = () => { r = b.dataset.r; draw() });
    $("#sw").onclick = () => { mode = mode === "up" ? "in" : "up"; draw() };
    $("#go1").onclick = async () => {
      const e = $("#em").value.trim(), p = $("#pw").value, n = $("#nm") ? $("#nm").value.trim() : "";
      if (!e || p.length < 6) return toast("اكتب إيميل وكلمة سر 6 حروف على الأقل");
      if (mode === "up" && !n) return toast("اكتب اسمك");
      try {
        if (mode === "up") await B.signUp(e, p, n); else await B.signIn(e, p);
        const after = store.get("after"); store.set("after", "");
        if (mode === "up" && r === "seller") go("#/me"); else go(after || "#/");
      } catch (x) { toast(authErr(x)) }
    };
  };
  draw();
}
function authErr(x) {
  const c = x.code || "";
  if (c.includes("email-already")) return "الإيميل ده مسجّل قبل كده، جرّب «دخول»";
  if (c.includes("wrong-password") || c.includes("invalid-credential") || c.includes("user-not-found")) return "الإيميل أو كلمة السر غلط";
  if (c.includes("weak-password")) return "كلمة السر ضعيفة";
  if (c.includes("invalid-email")) return "الإيميل مش مكتوب صح";
  return "تعذّر تسجيل الدخول: " + (c || x.message);
}

function compress(file, max = 800, q = 0.6) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onerror = rej;
    r.onload = () => { const im = new Image(); im.onerror = rej; im.onload = () => {
      const k = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement("canvas");
      c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
      c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL("image/jpeg", q));
    }; im.src = r.result };
    r.readAsDataURL(file);
  });
}

// ================= صفحتي =================
async function me() {
  if (!user) return login("seller");
  setTitle("صفحة مصنعي");
  const old = (await B.getMaker(user.uid)) || {};
  const L = lim(old), pro = hasPro(old);
  const f = { name: old.name || "", country: old.country || store.get("country") || "EG", city: old.city || "", desc: old.desc || "", phone: old.phone || "", wa: old.wa || "", cats: [...(old.cats || [])], photos: [...(old.photos || [])] };
  const prods = old.name ? await B.listProducts(user.uid) : [];
  const pend = old.name ? await B.listPending(user.uid) : [];
  const pPhotos = pend.filter(x => x.kind === "photo"), pProds = pend.filter(x => x.kind === "product");
  const lock = t => `<span class="lk">🔒 ${t}</span>`;
  view.innerHTML = `<div class="sm" style="color:var(--m)">${esc(user.name || "")} · ${esc(user.email)}</div>
  <div class="note" style="background:#e8f5e9;border-color:#a5d6a7;color:#1b5e20">🎁 الاشتراك مجاني لأول 3 شهور تبدأ من تاريخ التسجيل${old.created ? " — ينتهي في " + new Date(trialEnd(old)).toLocaleDateString("ar-EG") : ""}.</div>
  ${old.name ? `<h2>📊 إحصائيات صفحتك</h2><div class="stats">
    <div><b>${old.views | 0}</b><span>مرات فتح الصفحة</span></div>
    <div>${pro ? `<b>${old.waClicks | 0}</b>` : lock("اشترك")}<span>ضغطات واتساب</span></div>
    <div>${pro ? `<b>${old.callClicks | 0}</b>` : lock("اشترك")}<span>ضغطات اتصال</span></div>
    <div>${pro ? `<b>${old.shares | 0}</b>` : lock("اشترك")}<span>مشاركات</span></div></div>` : ""}
  ${user.verified === false ? `<div class="note">📧 إيميلك لسه مش مؤكَّد. افتح الرسالة اللي وصلتلك (شوف Spam كمان) واضغط الرابط${(window.ADMIN_EMAIL && String(user.email).toLowerCase() === String(window.ADMIN_EMAIL).toLowerCase()) ? " — <b>لازم تأكده عشان تفتح لوحة الإدارة</b>" : ""}.<div style="display:flex;gap:8px;margin-top:8px"><button class="chip" id="vsend">أرسل الرابط تاني</button><button class="chip" id="vchk">أكدت، حدّث</button></div></div>` : ""}
  <h2>بيانات المصنع / الورشة</h2>
  <label>الاسم</label><input id="f_name" value="${esc(f.name)}">
  <label>الدولة</label><select id="f_country">${COUNTRIES.map(c => `<option value="${c[0]}" ${c[0] === f.country ? "selected" : ""}>${c[2]} ${c[1]}</option>`).join("")}</select>
  <label>المدينة</label><select id="f_citysel"></select><input id="f_city" placeholder="اكتب اسم المدينة أو المنطقة" value="${esc(f.city)}" style="display:none">
  <label>اختر الأقسام اللي بتشتغل فيها</label>
  ${CATS.map(k => `<div class="sm" style="margin-top:6px;font-weight:700">${k.icon} ${k.name}</div><div class="chips">${k.sub.map(s => { const id = k.id + ":" + s[0]; return `<span class="chip ${f.cats.includes(id) ? "on" : ""}" data-id="${id}">${s[1]}</span>` }).join("")}</div>`).join("")}
  <label>وصف الشغل (إيه بتصنّع، أقل كمية، المميزات)</label><textarea id="f_desc">${esc(f.desc)}</textarea>
  <label>رقم الهاتف</label><input id="f_phone" type="tel" dir="ltr" value="${esc(f.phone)}">
  <label>رقم الواتساب بالكود الدولي (مثال: 201012345678)</label><input id="f_wa" type="tel" dir="ltr" value="${esc(f.wa)}">
  <label>صور الشغل (حتى ${L.photos} صور) — أي صورة جديدة بتتراجع قبل ما تظهر للناس</label>
  <div class="photos" id="ph"></div><input id="f_file" type="file" accept="image/*">
  <button class="btn" id="save">حفظ</button>
  ${old.name ? `<a class="btn l" href="#/m/${encodeURIComponent(user.uid)}">عرض صفحتي</a>` : ""}
  <h2>منتجاتي (${prods.length + pProds.length}/${L.products})</h2><div id="pl"></div>
  ${old.name ? `<div class="card" style="padding:12px"><b>إضافة منتج</b>
    <input id="p_name" placeholder="اسم المنتج"><input id="p_price" placeholder="السعر (اختياري)">
    <label>قسم المنتج</label><select id="p_cat">${(old.cats || []).map(c => `<option value="${esc(c)}">${esc(catName(c))}</option>`).join("")}</select>
    <textarea id="p_desc" placeholder="وصف قصير" style="min-height:60px"></textarea>
    <label>صور المنتج (${pro ? "حتى " + L.pphotos : "صورة واحدة"})</label><input id="p_file" type="file" accept="image/*" ${pro ? "multiple" : ""}>
    ${pro ? `<label>جدول مواصفات (اختياري) — مثال: الخامة ← قطن</label><div id="sp"></div><button class="chip" id="sp_add" type="button">＋ إضافة خاصية</button>
    <label style="margin-top:10px">جدول مقاسات (اختياري)</label><input id="sz_c" placeholder="الأعمدة بفاصلة: المقاس,الوسط,الورك,الطول"><textarea id="sz_r" placeholder="كل سطر صف: 28,71,95,101" style="min-height:60px"></textarea>`
      : `<div class="note">${lock("ضمن الاشتراك")} جدول المواصفات والمقاسات وصور متعددة وزرار «أرسل استفسار».</div>`}
    <button class="btn o" id="p_add">إضافة للمراجعة</button></div>` : `<div class="note">احفظ بيانات المصنع الأول عشان تقدر تضيف منتجات.</div>`}
  <h2>ترقية صفحتك</h2>
  <div class="card" style="padding:12px;display:grid;gap:10px">
    <button class="btn o up" data-k="top">⭐ اجعل صفحتك في أول العرض (بفلوس)</button>
    <button class="btn up" data-k="pro">🎨 احصل على صفحة احترافية</button>
    <button class="btn up" data-k="sub">✅ اشترك للمميزات (بدون إعلانات)</button>
    <div class="note" id="upnote" style="display:none"></div>
  </div>
  ${isAdmin() ? `<a class="btn o" href="#/admin">🛡 لوحة الإدارة</a>` : ""}
  ${helpBtn()}
  <div class="foot"><a href="#/privacy">الخصوصية</a> · <a href="#/terms">الشروط</a></div>
  <button class="btn r" id="out">تسجيل الخروج</button>
  <button class="chip" id="del0" style="display:block;margin:14px auto">حذف حسابي نهائياً</button><div id="delbox"></div>`;
  const fillCities = () => {
    const c = $("#f_country").value, list = CITIES[c] || [], cur = $("#f_city").value.trim();
    $("#f_citysel").innerHTML = `<option value="">اختر المدينة…</option>` + list.map(x => `<option ${x === cur ? "selected" : ""}>${esc(x)}</option>`).join("") + `<option value="__o" ${cur && !list.includes(cur) ? "selected" : ""}>${OTHER_CITY} (اكتبها)</option>`;
    $("#f_city").style.display = $("#f_citysel").value === "__o" ? "" : "none";
  };
  fillCities();
  $("#f_country").onchange = () => { $("#f_city").value = ""; fillCities() };
  $("#f_citysel").onchange = () => { const v = $("#f_citysel").value; if (v === "__o") { $("#f_city").value = ""; $("#f_city").style.display = ""; $("#f_city").focus() } else { $("#f_city").value = v; $("#f_city").style.display = "none" } };
  const renderPh = () => {
    $("#ph").innerHTML = f.photos.map((p, i) => `<div><img src="${p}" alt=""><b data-i="${i}">×</b></div>`).join("") + pPhotos.map(p => `<div class="pend"><img src="${p.photo}" alt=""><b data-p="${esc(p.id)}">×</b><span>قيد المراجعة</span></div>`).join("");
    $("#ph").querySelectorAll("b[data-i]").forEach(b => b.onclick = () => { f.photos.splice(+b.dataset.i, 1); renderPh() });
    $("#ph").querySelectorAll("b[data-p]").forEach(b => b.onclick = async () => { await B.delPending(user.uid, b.dataset.p); await B.clearFlag(user.uid); me() });
  };
  renderPh();
  view.querySelectorAll(".chips .chip").forEach(c => c.onclick = () => { const id = c.dataset.id, i = f.cats.indexOf(id); if (i < 0) f.cats.push(id); else f.cats.splice(i, 1); c.classList.toggle("on") });
  $("#f_file").onchange = async e => {
    const file = e.target.files[0]; e.target.value = ""; if (!file) return;
    if (!old.name) return toast("احفظ بيانات المصنع الأول، وبعدها ضيف الصور");
    if (f.photos.length + pPhotos.length >= L.photos) return toast("الحد الأقصى " + L.photos + " صور");
    try { const photo = await compress(file); await B.addPending(user.uid, { kind: "photo", photo }); toast("اتبعتت للمراجعة ✔"); me() } catch (x) { toast("تعذّر رفع الصورة: " + (x.code || x.message)) }
  };
  view.querySelectorAll(".up").forEach(b => b.onclick = async () => {
    if (!old.name) return toast("احفظ بيانات المصنع الأول");
    const k = b.dataset.k, names = { top: "الظهور في أول العرض", pro: "الصفحة الاحترافية", sub: "اشتراك المميزات" };
    const it = Array.from(new Set([...(old.interest || []), k]));
    try { await B.saveMaker(user.uid, { interest: it }); old.interest = it } catch (x) {}
    const n = $("#upnote"); n.style.display = "block";
    n.textContent = "تم تسجيل طلبك على «" + names[k] + "». الخدمة هتتفعّل قريباً وهنتواصل معاك بتفاصيل الأسعار.";
  });
  $("#save").onclick = async () => {
    const d = { name: $("#f_name").value.trim(), country: $("#f_country").value, city: $("#f_city").value.trim(), desc: $("#f_desc").value.trim(), phone: $("#f_phone").value.trim(), wa: $("#f_wa").value.replace(/\D/g, ""), cats: f.cats, photos: f.photos };
    if (!d.name) return toast("اكتب اسم المصنع أو الورشة");
    if (hasLink(d.name, d.city, d.desc)) return toast(LINK_MSG);
    if (!d.city) return toast("اختر المدينة");
    if (!d.cats.length) return toast("اختر قسم واحد على الأقل");
    if (!d.phone && !d.wa) return toast("اكتب رقم هاتف أو واتساب عشان العملاء يتواصلوا معاك");
    if (!old.name) { d.created = Date.now(); d.verified = false; d.featured = false; d.photos = [] }
    try { await B.saveMaker(user.uid, d); cache = {}; feedCache = null; store.set("country", d.country); toast("تم الحفظ ✔"); maybeRate(); me() } catch (x) { toast("تعذّر الحفظ: " + (x.code || x.message)) }
  };
  const renderPl = () => {
    $("#pl").innerHTML = (prods.length || pProds.length) ? `<div class="card">${prods.map(p => `<div class="pr">${(p.photos && p.photos[0]) || p.photo ? `<img src="${(p.photos && p.photos[0]) || p.photo}" alt="">` : ""}<div style="flex:1"><div class="nm">${esc(p.name)}</div><div class="sm">${esc(p.price || "")} · 👁 ${p.views | 0}</div></div><button class="chip" data-d="${esc(p.id)}">حذف</button></div>`).join("")}${pProds.map(p => `<div class="pr" style="opacity:.75">${p.photo ? `<img src="${p.photo}" alt="">` : ""}<div style="flex:1"><div class="nm">${esc(p.name)} <span class="badge f">قيد المراجعة</span></div><div class="sm">${esc(p.price || "")}</div></div><button class="chip" data-q="${esc(p.id)}">إلغاء</button></div>`).join("")}</div>` : `<div class="sm" style="color:var(--m)">لسه ما أضفتش منتجات.</div>`;
    $("#pl").querySelectorAll("[data-d]").forEach(b => b.onclick = async () => { await B.deleteProduct(user.uid, b.dataset.d); feedCache = null; prods.splice(prods.findIndex(x => x.id === b.dataset.d), 1); renderPl() });
    $("#pl").querySelectorAll("[data-q]").forEach(b => b.onclick = async () => { await B.delPending(user.uid, b.dataset.q); await B.clearFlag(user.uid); me() });
  };
  renderPl();
  // مواصفات
  const specs = [{ k: "", v: "" }];
  const renderSp = () => {
    if (!$("#sp")) return;
    $("#sp").innerHTML = specs.map((s, i) => `<div class="sprow"><input data-k="${i}" placeholder="الخاصية" value="${esc(s.k)}"><input data-v="${i}" placeholder="القيمة" value="${esc(s.v)}"><b data-x="${i}">×</b></div>`).join("");
    $("#sp").querySelectorAll("[data-k]").forEach(i => i.oninput = () => specs[+i.dataset.k].k = i.value);
    $("#sp").querySelectorAll("[data-v]").forEach(i => i.oninput = () => specs[+i.dataset.v].v = i.value);
    $("#sp").querySelectorAll("[data-x]").forEach(b => b.onclick = () => { specs.splice(+b.dataset.x, 1); if (!specs.length) specs.push({ k: "", v: "" }); renderSp() });
  };
  renderSp();
  if ($("#sp_add")) $("#sp_add").onclick = () => { if (specs.length < 20) { specs.push({ k: "", v: "" }); renderSp() } };
  if ($("#p_add")) $("#p_add").onclick = async () => {
    const n = $("#p_name").value.trim(); if (!n) return toast("اكتب اسم المنتج");
    if (!(old.cats || []).length) return toast("اختر أقسام لمصنعك الأول");
    if (prods.length + pProds.length >= L.products) return toast("وصلت للحد الأقصى في باقتك");
    const sp = pro ? specs.filter(s => s.k.trim() && s.v.trim()).map(s => ({ k: s.k.trim(), v: s.v.trim() })) : [];
    let sizes = null;
    if (pro && $("#sz_c").value.trim()) {
      const sp2 = t => t.split(/[,،]/).map(x => x.trim());
      sizes = { cols: sp2($("#sz_c").value), rows: $("#sz_r").value.split("\n").map(l => l.trim()).filter(Boolean).slice(0, 25).map(sp2) };
    }
    if (hasLink(n, $("#p_price").value, $("#p_desc").value, ...sp.flatMap(s => [s.k, s.v]), ...(sizes ? [...sizes.cols, ...sizes.rows.flat()] : []))) return toast(LINK_MSG);
    const photos = [];
    const files = [...($("#p_file").files || [])].slice(0, L.pphotos);
    for (const fl of files) { try { photos.push(await compress(fl, 600, 0.55)) } catch (e) {} }
    try {
      await B.addPending(user.uid, { kind: "product", name: n, price: $("#p_price").value.trim(), desc: $("#p_desc").value.trim(), photo: photos[0] || "", photos, specs: sp, sizes, cat: $("#p_cat").value, country: old.country || "" });
      toast("اتبعت للمراجعة ✔ وهيظهر بعد الموافقة"); me();
    } catch (x) { toast("تعذّر الإضافة: " + (x.code || x.message)) }
  };
  if ($("#vsend")) $("#vsend").onclick = async () => { try { await B.sendVerify(); toast("اتبعت الرابط على إيميلك ✔") } catch (e) { toast("استنى شوية وجرّب تاني") } };
  if ($("#vchk")) $("#vchk").onclick = async () => { try { const u = await B.refreshUser(); user = u; toast(u.verified ? "تم التأكيد ✔" : "لسه ما اتأكدش"); me() } catch (e) { toast("تعذّر التحديث") } };
  $("#out").onclick = async () => { await B.signOut(); go("#/") };
  $("#del0").onclick = () => {
    $("#delbox").innerHTML = `<div class="card" style="padding:12px;border-color:#b3261e"><div style="line-height:1.7">هيتمسح حسابك وصفحتك ومنتجاتك وتقييماتك نهائياً ومش هينفع ترجعهم. اكتب <b>احذف</b> للتأكيد:</div><input id="del_t" placeholder="احذف"><button class="btn r" id="del1">تأكيد الحذف النهائي</button></div>`;
    $("#del1").onclick = async () => {
      if ($("#del_t").value.trim() !== "احذف") return toast("اكتب كلمة: احذف");
      try { await B.deleteAccount(user.uid); cache = {}; feedCache = null; toast("تم حذف حسابك"); go("#/") } catch (e) { toast((e.code || "").includes("recent") ? "من أجل الأمان اخرج وادخل تاني وبعدين جرّب الحذف" : "تعذّر الحذف: " + (e.code || e.message)) }
    };
  };
}

// ================= الإدارة =================
async function admin() {
  if (!isAdmin()) return home();
  setTitle("الإدارة");
  const pm = await B.listPendingMakers();
  const items = [];
  for (const m of pm) for (const it of await B.listPending(m.id)) items.push({ m, it });
  const reps = await B.listReports();
  const imgs = it => (it.photos && it.photos.length ? it.photos : (it.photo ? [it.photo] : [])).map(x => `<img src="${x}" alt="" style="width:100%;max-height:300px;object-fit:contain;border-radius:10px;margin:6px 0;background:#f0f3f2">`).join("");
  view.innerHTML = `<h2>🕒 قيد المراجعة (${items.length})</h2>
  ${items.length ? `<button class="btn" id="apall">✅ موافقة على الكل (${items.length})</button>` : `<div class="empty">مفيش حاجة قيد المراجعة 👌</div>`}
  ${items.map((x, i) => `<div class="card" style="padding:10px"><div class="sm"><b>${esc(x.m.name)}</b> — ${esc(x.m.city || "")}</div>
    <div class="sm" style="color:var(--m)">${x.it.kind === "photo" ? "صورة للمصنع" : "منتج: " + esc(x.it.name) + (x.it.price ? " — " + esc(x.it.price) : "") + (x.it.desc ? "<br>" + esc(x.it.desc) : "") + (x.it.specs && x.it.specs.length ? "<br>مواصفات: " + x.it.specs.map(s => esc(s.k) + ": " + esc(s.v)).join(" | ") : "") + (x.it.sizes && x.it.sizes.cols ? "<br>جدول مقاسات: " + x.it.sizes.cols.map(esc).join(" / ") : "")}</div>
    ${imgs(x.it)}
    <div style="display:flex;gap:8px"><button class="btn" data-a="${i}" style="margin:4px 0">✅ موافقة</button><button class="btn r" data-r="${i}" style="margin:4px 0">❌ رفض</button></div></div>`).join("")}
  <h2>🚩 البلاغات (${reps.length})</h2>
  ${reps.length ? reps.map((r, i) => `<div class="card" style="padding:10px"><div class="nm">${esc(r.name || r.maker)}</div><div class="sm">${esc(r.reason)}${r.review ? " — على تقييم" : ""}${r.product ? " — على منتج" : ""}</div><div class="sm" style="color:var(--m)">${esc(r.text0 || "")} ${esc(r.text || "")}${r.by ? "<br>من: " + esc(r.by) : ""}</div>
    <div style="display:flex;gap:6px;flex-wrap:wrap"><a class="chip" href="#/m/${encodeURIComponent(r.maker)}">فتح الصفحة</a>${r.product ? `<a class="chip" href="#/p/${encodeURIComponent(r.maker)}/${encodeURIComponent(r.product)}">فتح المنتج</a>` : ""}${r.review ? `<button class="chip" data-dr="${i}">🗑 حذف التقييم</button>` : ""}<button class="chip" data-h="${i}">🚫 إخفاء الصفحة</button><button class="chip" data-u="${i}">إظهار</button><button class="chip" data-x="${i}">تجاهل البلاغ</button></div></div>`).join("") : `<div class="empty">مفيش بلاغات</div>`}`;
  const done = msg => { cache = {}; feedCache = null; toast(msg); admin() };
  view.querySelectorAll("[data-a]").forEach(b => b.onclick = async () => { const x = items[+b.dataset.a]; try { await B.approve(x.m.id, x.it); done("تمت الموافقة ✔") } catch (e) { toast("تعذّر: " + (e.code || e.message)) } });
  view.querySelectorAll("[data-r]").forEach(b => b.onclick = async () => { const x = items[+b.dataset.r]; try { await B.reject(x.m.id, x.it); done("تم الرفض") } catch (e) { toast("تعذّر: " + (e.code || e.message)) } });
  if ($("#apall")) $("#apall").onclick = async () => { try { for (const x of items) await B.approve(x.m.id, x.it); done("تمت الموافقة على الكل ✔") } catch (e) { toast("تعذّر: " + (e.code || e.message)) } };
  view.querySelectorAll("[data-h]").forEach(b => b.onclick = async () => { await B.saveMaker(reps[+b.dataset.h].maker, { hidden: true }); done("اتخفت الصفحة") });
  view.querySelectorAll("[data-u]").forEach(b => b.onclick = async () => { await B.saveMaker(reps[+b.dataset.u].maker, { hidden: false }); done("رجعت الصفحة") });
  view.querySelectorAll("[data-dr]").forEach(b => b.onclick = async () => { const r = reps[+b.dataset.dr]; await B.delReview(r.review); await B.delReport(r.id); done("اتحذف التقييم") });
  view.querySelectorAll("[data-x]").forEach(b => b.onclick = async () => { await B.delReport(reps[+b.dataset.x].id); done("اتمسح البلاغ") });
}

// ================= المساعدة والسياسات =================
function help() {
  setTitle("الدعم");
  const wa = (window.SUPPORT_WA || "").replace(/\D/g, ""), em = window.SUPPORT_EMAIL || "";
  view.innerHTML = `<h2>🛟 الدعم</h2>
  <div class="note">لو عندك مشكلة في التسجيل أو في صفحتك أو في استخدام التطبيق، ابعتلنا وهنرد عليك في أقرب وقت. اكتب اسم مصنعك والدولة ووصف المشكلة.</div>
  ${wa ? `<a class="btn" style="background:#25a244" href="https://wa.me/${wa}?text=${encodeURIComponent("محتاج مساعدة في تطبيق مصنّعي الوطن العربي")}">💬 تواصل واتساب</a>` : ""}
  ${em ? `<a class="btn l" href="mailto:${esc(em)}?subject=${encodeURIComponent("الدعم - مصنّعي الوطن العربي")}">✉️ ابعتلنا إيميل</a>` : ""}
  ${!wa && !em ? `<div class="note">وسيلة التواصل مع الدعم هتتضاف قريباً.</div>` : ""}`;
}
function helpBtn() { return `<a class="btn l" href="#/help">🛟 الدعم</a>` }

function legal(kind) {
  const em = window.SUPPORT_EMAIL || "[إيميل الدعم]";
  setTitle(kind === "terms" ? "الشروط والأحكام" : "سياسة الخصوصية");
  const T = {
    terms: `<h2>الشروط والأحكام</h2><div class="legal">
<p><b>1. طبيعة الخدمة:</b> «مصنّعي الوطن العربي» منصّة تعارف بين المصنّعين والورش والتجّار. التطبيق <b>وسيط فقط</b>، ولا يشارك في أي بيع أو دفع أو شحن، وغير مسؤول عن أي اتفاق أو صفقة بين الطرفين. ننصح بزيارة المصنع ومعاينة الشغل بنفسك قبل الاتفاق.</p>
<p><b>2. الحساب:</b> أنت مسؤول عن صحة بياناتك وعن سرية كلمة السر. يحقّ لك حذف حسابك في أي وقت من صفحة «صفحتي».</p>
<p><b>3. المحتوى:</b> أنت مسؤول عن كل ما تنشره (نصوص وصور). يُمنع نشر: محتوى غير لائق أو إباحي، أو مخالف للقانون، أو مسروق، أو احتيالي، أو روابط وإعلانات لجهات أخرى. نراجع الصور والمنتجات قبل ظهورها، ويحقّ لنا رفض أو حذف أي محتوى، وإخفاء أو حظر أي حساب مخالف دون إنذار.</p>
<p><b>4. الإبلاغ:</b> يمكن لأي مستخدم الإبلاغ عن صفحة أو منتج أو تقييم، وسنراجع البلاغات.</p>
<p><b>5. التقييمات:</b> يجب أن تعبّر عن تجربة حقيقية وبأسلوب محترم. التقييمات المسيئة أو الكاذبة تُحذف.</p>
<p><b>6. الاشتراكات:</b> الاشتراك مجاني لأول 3 شهور من تاريخ التسجيل. بعدها قد تتوفّر باقات مدفوعة بمميزات إضافية، وسنعلن الأسعار والشروط قبل تطبيقها، ولا يتم خصم أي مبلغ دون موافقتك.</p>
<p><b>7. التعديلات:</b> قد نعدّل هذه الشروط، واستمرارك في الاستخدام يعني موافقتك عليها.</p>
<p><b>8. التواصل:</b> ${esc(em)}</p></div>`,
    privacy: `<h2>سياسة الخصوصية</h2><div class="legal">
<p><b>البيانات التي نجمعها:</b> الاسم والبريد الإلكتروني (للحساب)، وبيانات المصنع التي تكتبها (الاسم، المدينة، الأقسام، الوصف، رقم الهاتف والواتساب)، والصور والمنتجات التي ترفعها، والتقييمات التي تكتبها، وأرقام استخدام مجمّعة (عدد مرات فتح الصفحة والضغط على أزرار التواصل).</p>
<p><b>كيف نستخدمها:</b> لتشغيل الحساب وعرض صفحات المصنّعين والمنتجات للمستخدمين، وتمكين المشترين من التواصل مع المصنّعين، ومراجعة المحتوى ومنع المخالفات، وتحسين الخدمة. <b>لا نبيع بياناتك.</b></p>
<p><b>من يرى بياناتك:</b> بيانات صفحة المصنع (الاسم والمدينة والوصف والصور والمنتجات) ظاهرة للجميع. رقم الهاتف والواتساب يظهران للمستخدمين المسجّلين فقط. التقييم يظهر باسمك.</p>
<p><b>التخزين:</b> نستخدم خدمات Google Firebase (المصادقة وقاعدة البيانات) لتخزين البيانات وحمايتها.</p>
<p><b>الإعلانات:</b> قد نعرض إعلانات في الباقة المجانية لاحقاً، وسنحدّث هذه السياسة عند ذلك.</p>
<p><b>حذف بياناتك:</b> يمكنك حذف حسابك وكل بياناتك من داخل التطبيق: «صفحتي» ← «حذف حسابي نهائياً». أو راسلنا على ${esc(em)}.</p>
<p><b>الأطفال:</b> التطبيق غير موجّه لمن هم دون 18 عاماً.</p>
<p><b>التواصل:</b> ${esc(em)}</p></div>`
  };
  view.innerHTML = T[kind];
}
