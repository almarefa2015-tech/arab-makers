import B from "./backend.js";
import { COUNTRIES, CATS, catName, countryName } from "./data.js";

const $ = s => document.querySelector(s);
const view = $("#view"), titleEl = $("#title");
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const store = { get(k) { try { return localStorage.getItem(k) } catch (e) { return null } }, set(k, v) { try { localStorage.setItem(k, v) } catch (e) {} } };
let user = null, cache = {}, history_ = [];
const FREE_PHOTOS = 3, FREE_PRODUCTS = 8;

if (B.demo) $("#demo").hidden = false;
function toast(t) { const e = $("#toast"); e.textContent = t; e.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => e.hidden = true, 2600) }
function setTitle(t) { titleEl.textContent = t }
const go = h => { location.hash = h };
$("#back").onclick = () => { if (history.length > 1 && location.hash && location.hash !== "#/") history.back(); else go("#/") };
$("#acct").onclick = () => go(user ? "#/me" : "#/login");

B.onAuth(u => { user = u; route() });
window.addEventListener("hashchange", route);

async function makers(c, force) { if (force || !cache[c]) cache[c] = await B.listMakers(c); return cache[c] }
const rank = (a, b) => (b.featured | 0) - (a.featured | 0) || (b.verified | 0) - (a.verified | 0) || (b.created || 0) - (a.created || 0);

async function route() {
  const p = (location.hash || "#/").slice(2).split("/").map(decodeURIComponent);
  window.scrollTo(0, 0);
  $("#back").style.visibility = p[0] ? "visible" : "hidden";
  try {
    if (!p[0]) return home();
    if (p[0] === "c") return p[2] === "cat" ? list(p[1], p[3]) : country(p[1]);
    if (p[0] === "m") return maker(p[1]);
    if (p[0] === "login") return login();
    if (p[0] === "me") return me();
    home();
  } catch (e) { view.innerHTML = `<div class="empty">حصلت مشكلة في التحميل. تأكد من الإنترنت وجرّب تاني.<br><small>${esc(e.message)}</small></div>` }
}

function home() {
  setTitle("مصنّعي الوطن العربي");
  const last = store.get("country");
  view.innerHTML = `<h2>اختر دولتك</h2><div class="grid">${COUNTRIES.map(c => `<div class="tile" data-c="${c[0]}"><span>${c[2]}</span>${c[1]}</div>`).join("")}</div>
  <div class="note">منصّة تعارف بين المصنّعين والورش والتجّار في الوطن العربي. التسجيل مجاني.</div>
  <a class="btn o" href="#/me">سجّل مصنعك أو ورشتك مجانًا</a>`;
  view.querySelectorAll(".tile").forEach(t => t.onclick = () => { store.set("country", t.dataset.c); go("#/c/" + t.dataset.c) });
}

async function country(c) {
  setTitle(countryName(c));
  view.innerHTML = `<input id="q" type="search" placeholder="ابحث عن مصنع أو منتج...">
  <div id="res"></div><div id="cats"><h2>الأقسام</h2>${CATS.map(k => `<div class="cat" data-k="${k.id}"><div class="h"><span>${k.icon}</span><span>${k.name}</span><span class="ar">›</span></div><div class="subs">
  <div data-cat="${k.id}"><b>كل ${k.name}</b></div>${k.sub.map(s => `<div data-cat="${k.id}:${s[0]}">${s[1]}</div>`).join("")}</div></div>`).join("")}</div>
  <a class="btn l" href="#/c/${c}/cat/all">عرض كل المصنّعين في ${esc(countryName(c))}</a>`;
  view.querySelectorAll(".cat>.h").forEach(h => h.onclick = () => h.parentElement.classList.toggle("open"));
  view.querySelectorAll(".subs div").forEach(d => d.onclick = () => go(`#/c/${c}/cat/${encodeURIComponent(d.dataset.cat)}`));
  const q = $("#q"), res = $("#res");
  q.oninput = async () => {
    const t = q.value.trim().toLowerCase();
    $("#cats").style.display = t ? "none" : "";
    if (!t) { res.innerHTML = ""; return }
    const all = await makers(c);
    const hit = all.filter(m => (m.name + " " + m.desc + " " + m.city + " " + (m.cats || []).map(catName).join(" ")).toLowerCase().includes(t)).sort(rank);
    res.innerHTML = hit.length ? hit.map(card).join("") : `<div class="empty">مفيش نتائج لـ «${esc(t)}»</div>`;
    bindCards(res);
  };
}

function card(m) {
  const im = m.photos && m.photos[0] ? `<img class="thumb" src="${m.photos[0]}" alt="">` : `<div class="thumb">🏭</div>`;
  return `<div class="card ${m.featured ? "feat" : ""}"><div class="row" data-id="${esc(m.id)}">${im}<div><div class="nm">${esc(m.name)}${m.verified ? '<span class="badge">موثّق</span>' : ""}${m.featured ? '<span class="badge f">مميّز</span>' : ""}</div>
  <div class="sm">📍 ${esc(m.city || "")}</div><div class="sm">${esc((m.desc || "").slice(0, 70))}${(m.desc || "").length > 70 ? "…" : ""}</div></div></div></div>`;
}
const bindCards = root => root.querySelectorAll(".row[data-id]").forEach(r => r.onclick = () => go("#/m/" + encodeURIComponent(r.dataset.id)));

async function list(c, cat) {
  const all = await makers(c);
  const name = cat === "all" ? "كل المصنّعين" : (CATS.find(k => k.id === cat)?.name || catName(cat));
  setTitle(name);
  const hit = all.filter(m => cat === "all" || (m.cats || []).some(x => x === cat || x.startsWith(cat + ":"))).sort(rank);
  view.innerHTML = `<div class="sm" style="color:var(--m);margin-bottom:10px">${esc(countryName(c))} — ${hit.length} نتيجة</div>` +
    (hit.length ? hit.map(card).join("") : `<div class="empty">لسه مفيش مصنّعين في القسم ده.<br>كن أول من يسجّل!</div><a class="btn o" href="#/me">سجّل مصنعك مجانًا</a>`);
  bindCards(view);
}

async function maker(id) {
  const m = await B.getMaker(id);
  if (!m) { view.innerHTML = `<div class="empty">الصفحة دي مش موجودة.</div>`; return }
  setTitle(m.name);
  const prods = await B.listProducts(id);
  const wa = String(m.wa || m.phone || "").replace(/\D/g, "");
  const base = window.SHARE_BASE || "";
  const link = base ? base + "#/m/" + encodeURIComponent(id) : "";
  view.innerHTML = `${m.photos?.length ? `<div class="gal">${m.photos.map(p => `<img src="${p}" alt="">`).join("")}</div>` : ""}
  <h2 style="margin-top:12px">${esc(m.name)}${m.verified ? '<span class="badge">موثّق</span>' : ""}</h2>
  <div class="sm" style="color:var(--m)">📍 ${esc(m.city || "")} — ${esc(countryName(m.country))}</div>
  <div class="chips">${(m.cats || []).map(x => `<span class="chip">${esc(catName(x))}</span>`).join("")}</div>
  <p style="line-height:1.8;white-space:pre-wrap">${esc(m.desc || "")}</p>
  ${wa ? `<a class="btn w" href="https://wa.me/${wa}" target="_blank" rel="noopener">💬 تواصل واتساب</a>` : ""}
  ${m.phone ? `<a class="btn l" href="tel:${esc(m.phone)}">📞 اتصال ${esc(m.phone)}</a>` : ""}
  <button class="btn l" id="share">🔗 مشاركة الصفحة</button>
  ${prods.length ? `<h2>المنتجات</h2><div class="card">${prods.map(p => `<div class="pr">${p.photo ? `<img src="${p.photo}" alt="">` : ""}<div><div class="nm">${esc(p.name)}</div><div class="sm">${esc(p.price || "")}</div><div class="sm">${esc(p.desc || "")}</div></div></div>`).join("")}</div>` : ""}
  <div class="note">التطبيق وسيط تعارف فقط، وغير مسؤول عن أي اتفاق أو صفقة. ننصح بزيارة المصنع ومعاينة الشغل بنفسك قبل الاتفاق.</div>`;
  $("#share").onclick = async () => {
    const text = m.name + " — " + (m.city || "") + "\nللتواصل: " + (m.phone || m.wa || "") + (link ? "\n" + link : "");
    try { if (navigator.share) await navigator.share({ title: m.name, text }); else { await navigator.clipboard.writeText(text); toast("تم نسخ البيانات") } } catch (e) { toast("تعذّرت المشاركة") }
  };
}

function login() {
  setTitle("حسابي");
  view.innerHTML = `<h2>تسجيل الدخول أو إنشاء حساب</h2>
  <label>البريد الإلكتروني</label><input id="em" type="email" autocomplete="email" dir="ltr">
  <label>كلمة السر (6 حروف على الأقل)</label><input id="pw" type="password" autocomplete="current-password" dir="ltr">
  <button class="btn" id="in">دخول</button><button class="btn l" id="up">إنشاء حساب جديد</button>`;
  const run = async fn => {
    const e = $("#em").value.trim(), p = $("#pw").value;
    if (!e || p.length < 6) return toast("اكتب إيميل وكلمة سر 6 حروف على الأقل");
    try { await fn(e, p); go("#/me") } catch (x) { toast(authErr(x)) }
  };
  $("#in").onclick = () => run(B.signIn); $("#up").onclick = () => run(B.signUp);
}
function authErr(x) {
  const c = x.code || "";
  if (c.includes("email-already")) return "الإيميل ده مسجّل قبل كده، جرّب «دخول»";
  if (c.includes("wrong-password") || c.includes("invalid-credential") || c.includes("user-not-found")) return "الإيميل أو كلمة السر غلط";
  if (c.includes("weak-password")) return "كلمة السر ضعيفة";
  if (c.includes("invalid-email")) return "الإيميل مش مكتوب صح";
  return "تعذّر تسجيل الدخول: " + (c || x.message);
}

function compress(file, max = 800, q = 0.6) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onerror = rej;
    r.onload = () => { const im = new Image(); im.onerror = rej; im.onload = () => {
      const k = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement("canvas");
      c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
      c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL("image/jpeg", q));
    }; im.src = r.result };
    r.readAsDataURL(file);
  });
}

async function me() {
  if (!user) return login();
  setTitle("صفحة مصنعي");
  const old = (await B.getMaker(user.uid)) || {};
  const f = { name: old.name || "", country: old.country || store.get("country") || "EG", city: old.city || "", desc: old.desc || "", phone: old.phone || "", wa: old.wa || "", cats: [...(old.cats || [])], photos: [...(old.photos || [])] };
  const prods = old.name ? await B.listProducts(user.uid) : [];
  view.innerHTML = `<div class="sm" style="color:var(--m)">${esc(user.email)}</div>
  <h2>بيانات المصنع / الورشة</h2>
  <label>الاسم</label><input id="f_name" value="${esc(f.name)}">
  <label>الدولة</label><select id="f_country">${COUNTRIES.map(c => `<option value="${c[0]}" ${c[0] === f.country ? "selected" : ""}>${c[2]} ${c[1]}</option>`).join("")}</select>
  <label>المدينة / المنطقة</label><input id="f_city" value="${esc(f.city)}">
  <label>اختر الأقسام اللي بتشتغل فيها</label>
  ${CATS.map(k => `<div class="sm" style="margin-top:6px;font-weight:700">${k.icon} ${k.name}</div><div class="chips">${k.sub.map(s => { const id = k.id + ":" + s[0]; return `<span class="chip ${f.cats.includes(id) ? "on" : ""}" data-id="${id}">${s[1]}</span>` }).join("")}</div>`).join("")}
  <label>وصف الشغل (إيه بتصنّع، أقل كمية، المميزات)</label><textarea id="f_desc">${esc(f.desc)}</textarea>
  <label>رقم الهاتف</label><input id="f_phone" type="tel" dir="ltr" value="${esc(f.phone)}">
  <label>رقم الواتساب بالكود الدولي (مثال: 201012345678)</label><input id="f_wa" type="tel" dir="ltr" value="${esc(f.wa)}">
  <label>صور الشغل (حتى ${FREE_PHOTOS} صور مجانًا)</label>
  <div class="photos" id="ph"></div><input id="f_file" type="file" accept="image/*">
  <button class="btn" id="save">حفظ</button>
  ${old.name ? `<a class="btn l" href="#/m/${encodeURIComponent(user.uid)}">عرض صفحتي</a>` : ""}
  <h2>منتجاتي (${prods.length}/${FREE_PRODUCTS})</h2><div id="pl"></div>
  ${old.name ? `<div class="card" style="padding:12px"><b>إضافة منتج</b><input id="p_name" placeholder="اسم المنتج"><input id="p_price" placeholder="السعر (اختياري)"><textarea id="p_desc" placeholder="وصف قصير" style="min-height:60px"></textarea><input id="p_file" type="file" accept="image/*"><button class="btn o" id="p_add">إضافة</button></div>` : `<div class="note">احفظ بيانات المصنع الأول عشان تقدر تضيف منتجات.</div>`}
  <h2>مميزات قادمة (مدفوعة)</h2>
  <div class="card lock" style="padding:12px;line-height:2">🎨 صفحة بألوانك وتصميمك<br>🎬 رفع فيديو<br>✅ شارة «موثّق»<br>⭐ الظهور في أول القسم</div>
  <button class="btn r" id="out">تسجيل الخروج</button>`;
  const renderPh = () => { $("#ph").innerHTML = f.photos.map((p, i) => `<div><img src="${p}" alt=""><b data-i="${i}">×</b></div>`).join(""); $("#ph").querySelectorAll("b").forEach(b => b.onclick = () => { f.photos.splice(+b.dataset.i, 1); renderPh() }) };
  renderPh();
  view.querySelectorAll(".chips .chip").forEach(c => c.onclick = () => { const id = c.dataset.id, i = f.cats.indexOf(id); if (i < 0) f.cats.push(id); else f.cats.splice(i, 1); c.classList.toggle("on") });
  $("#f_file").onchange = async e => {
    const file = e.target.files[0]; e.target.value = ""; if (!file) return;
    if (f.photos.length >= FREE_PHOTOS) return toast("الحد الأقصى " + FREE_PHOTOS + " صور في الباقة المجانية");
    try { f.photos.push(await compress(file)); renderPh() } catch (x) { toast("تعذّر قراءة الصورة") }
  };
  $("#save").onclick = async () => {
    const d = { name: $("#f_name").value.trim(), country: $("#f_country").value, city: $("#f_city").value.trim(), desc: $("#f_desc").value.trim(), phone: $("#f_phone").value.trim(), wa: $("#f_wa").value.replace(/\D/g, ""), cats: f.cats, photos: f.photos };
    if (!d.name) return toast("اكتب اسم المصنع أو الورشة");
    if (!d.cats.length) return toast("اختر قسم واحد على الأقل");
    if (!d.phone && !d.wa) return toast("اكتب رقم هاتف أو واتساب عشان العملاء يتواصلوا معاك");
    if (!old.name) { d.created = Date.now(); d.verified = false; d.featured = false }
    try { await B.saveMaker(user.uid, d); cache = {}; store.set("country", d.country); toast("تم الحفظ ✔"); me() } catch (x) { toast("تعذّر الحفظ: " + (x.code || x.message)) }
  };
  const renderPl = () => { $("#pl").innerHTML = prods.length ? `<div class="card">${prods.map(p => `<div class="pr">${p.photo ? `<img src="${p.photo}" alt="">` : ""}<div style="flex:1"><div class="nm">${esc(p.name)}</div><div class="sm">${esc(p.price || "")}</div></div><button class="chip" data-d="${esc(p.id)}">حذف</button></div>`).join("")}</div>` : `<div class="sm" style="color:var(--m)">لسه ما أضفتش منتجات.</div>`;
    $("#pl").querySelectorAll("[data-d]").forEach(b => b.onclick = async () => { await B.deleteProduct(user.uid, b.dataset.d); prods.splice(prods.findIndex(x => x.id === b.dataset.d), 1); renderPl() }) };
  renderPl();
  if ($("#p_add")) $("#p_add").onclick = async () => {
    const n = $("#p_name").value.trim(); if (!n) return toast("اكتب اسم المنتج");
    if (prods.length >= FREE_PRODUCTS) return toast("وصلت للحد الأقصى في الباقة المجانية");
    let photo = ""; const fl = $("#p_file").files[0]; if (fl) { try { photo = await compress(fl, 600, 0.55) } catch (e) {} }
    try { await B.addProduct(user.uid, { name: n, price: $("#p_price").value.trim(), desc: $("#p_desc").value.trim(), photo }); toast("تمت الإضافة ✔"); me() } catch (x) { toast("تعذّر الإضافة: " + (x.code || x.message)) }
  };
  $("#out").onclick = async () => { await B.signOut(); go("#/") };
}
