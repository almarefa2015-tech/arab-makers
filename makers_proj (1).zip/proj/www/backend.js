// طبقة الخلفية: Firebase الحقيقي، أو وضع تجريبي بالذاكرة لو مفيش إعدادات
const V = "10.12.2";
let impl;
if (window.FIREBASE_CONFIG) {
  const base = `https://www.gstatic.com/firebasejs/${V}/`;
  const [{ initializeApp }, A, S] = await Promise.all([
    import(base + "firebase-app.js"), import(base + "firebase-auth.js"), import(base + "firebase-firestore.js")
  ]);
  const app = initializeApp(window.FIREBASE_CONFIG);
  const auth = A.getAuth(app), db = S.getFirestore(app);
  impl = {
    demo: false,
    onAuth: cb => A.onAuthStateChanged(auth, u => cb(u ? { uid: u.uid, email: u.email } : null)),
    signUp: (e, p) => A.createUserWithEmailAndPassword(auth, e, p),
    signIn: (e, p) => A.signInWithEmailAndPassword(auth, e, p),
    signOut: () => A.signOut(auth),
    async listMakers(country) {
      const q = S.query(S.collection(db, "makers"), S.where("country", "==", country), S.limit(300));
      return (await S.getDocs(q)).docs.map(d => ({ id: d.id, ...d.data() }));
    },
    async getMaker(id) { const d = await S.getDoc(S.doc(db, "makers", id)); return d.exists() ? { id, ...d.data() } : null; },
    async saveMaker(uid, data) { await S.setDoc(S.doc(db, "makers", uid), data, { merge: true }); },
    async listProducts(id) { return (await S.getDocs(S.collection(db, "makers", id, "products"))).docs.map(d => ({ id: d.id, ...d.data() })); },
    async addProduct(uid, p) { await S.addDoc(S.collection(db, "makers", uid, "products"), p); },
    async deleteProduct(uid, pid) { await S.deleteDoc(S.doc(db, "makers", uid, "products", pid)); }
  };
} else {
  // ---- وضع تجريبي ----
  const ls = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d } catch (e) { return d } };
  const sv = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)) } catch (e) {} };
  let makers = ls("demo_makers", null);
  if (!makers) {
    makers = [
      { id: "d1", name: "مصنع النيل للملابس الجاهزة", country: "EG", city: "القاهرة - العبور", cats: ["clothes:women", "clothes:jeans"], desc: "ننتج ملابس حريمي وجينز بالجملة، أقل كمية 50 قطعة، خامات مصرية وتسليم خلال 10 أيام.", phone: "01000000001", wa: "201000000001", photos: [], verified: true, featured: true, created: 3 },
      { id: "d2", name: "ورشة الأمل لأثاث غرف النوم", country: "EG", city: "دمياط", cats: ["furniture:home", "furniture:wood"], desc: "غرف نوم وأطقم صالون بتصميمات حديثة، نصنع حسب الطلب.", phone: "01000000002", wa: "201000000002", photos: [], verified: false, featured: false, created: 2 },
      { id: "d3", name: "الحرفة للبلاستيك المنزلي", country: "EG", city: "6 أكتوبر", cats: ["plastic:houseware"], desc: "أدوات منزلية بلاستيك: سلال، أحواض، علب تخزين.", phone: "01000000003", wa: "201000000003", photos: [], verified: false, featured: false, created: 1 },
      { id: "d4", name: "نجوم الخليج للتغليف", country: "AE", city: "الشارقة", cats: ["pack:cartons"], desc: "كراتين تغليف وطباعة بالجملة.", phone: "0500000004", wa: "9710500000004", photos: [], verified: true, featured: false, created: 1 }
    ];
    sv("demo_makers", makers);
  }
  let products = ls("demo_products", { d1: [{ id: "p1", name: "فستان سواريه", price: "350 جنيه للقطعة", desc: "مقاسات 36 إلى 50", photo: "" }] });
  let user = ls("demo_user", null); const subs = [];
  const emit = () => subs.forEach(f => f(user));
  impl = {
    demo: true,
    onAuth: cb => { subs.push(cb); setTimeout(() => cb(user), 0); },
    async signUp(e, p) { user = { uid: "u_" + e.replace(/\W/g, ""), email: e }; sv("demo_user", user); emit(); },
    async signIn(e, p) { user = { uid: "u_" + e.replace(/\W/g, ""), email: e }; sv("demo_user", user); emit(); },
    async signOut() { user = null; sv("demo_user", null); emit(); },
    async listMakers(c) { return makers.filter(m => m.country === c); },
    async getMaker(id) { return makers.find(m => m.id === id) || null; },
    async saveMaker(uid, d) { const i = makers.findIndex(m => m.id === uid); if (i < 0) makers.push({ id: uid, ...d }); else makers[i] = { ...makers[i], ...d }; sv("demo_makers", makers); },
    async listProducts(id) { return products[id] || []; },
    async addProduct(uid, p) { (products[uid] = products[uid] || []).push({ id: "p" + Date.now(), ...p }); sv("demo_products", products); },
    async deleteProduct(uid, pid) { products[uid] = (products[uid] || []).filter(x => x.id !== pid); sv("demo_products", products); }
  };
}
export default impl;
