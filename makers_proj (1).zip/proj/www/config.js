window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyAnAXTCaeTSOUfBpM8G-ZwNosHz3iHcvgI",
  authDomain: "arab-makers.firebaseapp.com",
  projectId: "arab-makers",
  storageBucket: "arab-makers.firebasestorage.app",
  messagingSenderId: "569614944909",
  appId: "1:569614944909:web:023bcce59558d0ff3f30c4"
};
window.SHARE_BASE = "";
